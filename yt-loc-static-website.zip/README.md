# YT-LOC — Modern WhatsApp-First Car Rental Website (Morocco)

This is the standalone, production-ready static website for **YT-LOC Car Rental & Mobility Morocco** (WhatsApp: `0653134372` / `+212 653-134372`, Email: `contact.yass@gmail.com`).

## How to Use or Host
1. **Open Directly in Any Browser**: Double-click `index.html` — no Node.js, npm, or backend server required.
2. **Deploy to Any Web Host**: Upload this folder (`index.html` and `assets/`) directly to Netlify, Vercel, GitHub Pages, Hostinger, cPanel, or any static web hosting provider.
